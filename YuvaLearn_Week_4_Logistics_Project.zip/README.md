# Logistics Predictive Modeling

YuvaLearn Week 4 internship project: Predictive Modeling and Optimization in Logistics Systems.

## Objective
Predict delivery time using distance, package weight, shipping cost, traffic level, and number of stops.

## Model
Linear Regression

## Evaluation
MAE, RMSE, R-squared, and 5-fold cross-validation.

## Files
- logistics_prediction.py — Python source code
- YuvaLearn_Week_4_Predictive_Modeling_Logistics_Report_With_Code_Output.docx — complete report with code output
