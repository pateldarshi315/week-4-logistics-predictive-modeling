import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

data = {
    "Distance_Km": [50,85,120,150,70,200,110,45,95,180,60,135],
    "Package_Weight_Kg": [2.5,4,5.5,8,3,10,6,2,4.5,9,2.8,7],
    "Shipping_Cost_INR": [350,500,700,950,450,1250,680,300,560,1100,400,820],
    "Traffic_Level": [2,3,2,5,1,4,3,1,3,5,2,4],
    "Number_of_Stops": [2,3,4,5,2,6,4,1,3,6,2,5],
    "Delivery_Time_Hours": [2.2,3.6,4.1,7.2,2.5,8.3,4.8,1.7,3.9,8.0,2.7,6.0]
}
df = pd.DataFrame(data)

X = df[["Distance_Km","Package_Weight_Kg","Shipping_Cost_INR",
        "Traffic_Level","Number_of_Stops"]]
y = df["Delivery_Time_Hours"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

mae = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
r2 = r2_score(y_test, y_pred)

print("MAE:", mae)
print("RMSE:", rmse)
print("R-squared:", r2)

cv_scores = cross_val_score(model, X, y, cv=5,
                            scoring="neg_mean_absolute_error")
print("Cross-Validation MAE:", -cv_scores.mean())

new_shipment = pd.DataFrame({
    "Distance_Km": [100],
    "Package_Weight_Kg": [5],
    "Shipping_Cost_INR": [650],
    "Traffic_Level": [3],
    "Number_of_Stops": [3]
})
print("Predicted Delivery Time:",
      round(model.predict(new_shipment)[0], 2), "hours")

df["Predicted_Delivery_Time"] = model.predict(X)
df["Priority"] = df["Predicted_Delivery_Time"].apply(
    lambda x: "High" if x > 6 else ("Medium" if x > 4 else "Normal")
)
print(df[["Distance_Km","Traffic_Level","Number_of_Stops",
          "Predicted_Delivery_Time","Priority"]])
